# Future Accountant

This application runs with a local SQLite database through the built-in Express server.

## Local setup

1. Install dependencies:

```bash
npm install
```

2. Create a local environment file:

```bash
cp .env.example .env
```

3. Start the app:

```bash
npm start
```

4. Open the application:

```text
http://127.0.0.1:3000
```

## Local database

- Default database file: `./data/future-accountant.sqlite`
- Health endpoint: `GET /api/health`
- Storage API: `GET|PUT|DELETE /api/storage/:key`

## Configuration

You can override these values in `.env`:

- `HOST`: server bind address
- `PORT`: HTTP port
- `DB_PATH`: SQLite database file path
- `JSON_BODY_LIMIT`: JSON payload size limit
