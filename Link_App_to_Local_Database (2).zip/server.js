const fs = require('fs');
const path = require('path');
const express = require('express');
const Database = require('better-sqlite3');

function loadEnvFile(filePath) {
    if (!fs.existsSync(filePath)) return;

    const envContent = fs.readFileSync(filePath, 'utf8');

    for (const rawLine of envContent.split(/\r?\n/)) {
        const line = rawLine.trim();
        if (!line || line.startsWith('#')) continue;

        const separatorIndex = line.indexOf('=');
        if (separatorIndex === -1) continue;

        const key = line.slice(0, separatorIndex).trim();
        if (!key || Object.prototype.hasOwnProperty.call(process.env, key)) continue;

        let value = line.slice(separatorIndex + 1).trim();
        if (
            (value.startsWith('"') && value.endsWith('"')) ||
            (value.startsWith("'") && value.endsWith("'"))
        ) {
            value = value.slice(1, -1);
        }

        process.env[key] = value;
    }
}

loadEnvFile(path.join(__dirname, '.env'));

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const DEFAULT_DB_PATH = path.join(__dirname, 'data', 'future-accountant.sqlite');
const DB_PATH = path.resolve(process.env.DB_PATH || DEFAULT_DB_PATH);
const DB_DIR = path.dirname(DB_PATH);
const JSON_BODY_LIMIT = process.env.JSON_BODY_LIMIT || '10mb';

fs.mkdirSync(DB_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
    CREATE TABLE IF NOT EXISTS kv_store (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );
`);

function createEmptyDatabasePayload() {
    return {
        clients: {},
        suppliers: {},
        debtors: {},
        employees: {},
        others: {},
        invoices: [],
        invoiceCounter: 1000
    };
}

function defaultDatabaseCatalog() {
    return [{
        id: 'default',
        name: 'الافتراضية',
        createdAt: new Date().toISOString()
    }];
}

function setValue(key, value) {
    const serialized = JSON.stringify(value);
    db.prepare(`
        INSERT INTO kv_store (key, value, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            updated_at = excluded.updated_at
    `).run(key, serialized, new Date().toISOString());
    return value;
}

function getRow(key) {
    return db.prepare('SELECT key, value, updated_at FROM kv_store WHERE key = ?').get(key);
}

function getValue(key) {
    const row = getRow(key);
    if (!row) return null;

    try {
        return JSON.parse(row.value);
    } catch {
        return row.value;
    }
}

function deleteValue(key) {
    return db.prepare('DELETE FROM kv_store WHERE key = ?').run(key);
}

function initializeDefaults() {
    if (getRow('fa_saved_databases')) return;

    const catalog = defaultDatabaseCatalog();
    const activeDatabaseId = 'default';
    const payload = createEmptyDatabasePayload();

    setValue('fa_saved_databases', catalog);
    setValue('fa_active_database_id', activeDatabaseId);
    setValue('fa_db_data_default', payload);
}

function hasMeaningfulData(payload) {
    if (!payload || typeof payload !== 'object') return false;

    return (
        Object.keys(payload.clients || {}).length > 0 ||
        Object.keys(payload.suppliers || {}).length > 0 ||
        Object.keys(payload.debtors || {}).length > 0 ||
        Object.keys(payload.employees || {}).length > 0 ||
        Object.keys(payload.others || {}).length > 0 ||
        (payload.invoices || []).length > 0 ||
        (payload.invoiceCounter || 1000) !== 1000
    );
}

function isPristineStore() {
    const catalog = getValue('fa_saved_databases');
    const activeDatabaseId = getValue('fa_active_database_id');
    const defaultState = getValue('fa_db_data_default');

    const onlyDefaultDatabase =
        Array.isArray(catalog) &&
        catalog.length === 1 &&
        catalog[0]?.id === 'default' &&
        activeDatabaseId === 'default';

    return onlyDefaultDatabase && !hasMeaningfulData(defaultState);
}

initializeDefaults();

app.use(express.json({ limit: JSON_BODY_LIMIT }));

app.get('/api/health', (req, res) => {
    res.json({
        ok: true,
        provider: 'sqlite',
        host: HOST,
        port: Number(PORT),
        dbPath: DB_PATH
    });
});

app.get('/api/storage/:key', (req, res) => {
    const { key } = req.params;
    const row = getRow(key);

    if (!row) {
        return res.status(404).json({ found: false });
    }

    res.json({
        found: true,
        key,
        value: getValue(key),
        updatedAt: row.updated_at
    });
});

app.put('/api/storage/:key', (req, res) => {
    const { key } = req.params;
    const { value } = req.body || {};

    if (typeof value === 'undefined') {
        return res.status(400).json({ error: 'Missing value' });
    }

    setValue(key, value);
    res.json({ ok: true, key, value });
});

app.delete('/api/storage/:key', (req, res) => {
    const { key } = req.params;
    deleteValue(key);
    res.json({ ok: true, key });
});

app.post('/api/bootstrap', (req, res) => {
    const { entries } = req.body || {};

    if (!Array.isArray(entries) || entries.length === 0) {
        return res.status(400).json({ error: 'Entries array is required' });
    }

    if (!isPristineStore()) {
        return res.json({ ok: true, skipped: true, reason: 'store_not_pristine' });
    }

    const insertMany = db.transaction((items) => {
        for (const entry of items) {
            if (!entry || typeof entry.key !== 'string') continue;
            if (typeof entry.value === 'undefined') continue;
            setValue(entry.key, entry.value);
        }
    });

    insertMany(entries);
    res.json({ ok: true, imported: entries.length });
});

app.use(express.static(__dirname));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.use((error, req, res, next) => {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, HOST, () => {
    console.log(`Future Accountant server running at http://${HOST}:${PORT}`);
    console.log(`SQLite database: ${DB_PATH}`);
});
